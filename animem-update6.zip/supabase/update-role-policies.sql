-- ============================================================
-- ANIMEM — Zusatz-Migration: Rollenänderung durch Head Admin/Owner
-- Im Supabase SQL Editor einmalig ausführen (Teil 6)
--
-- Bisher durfte laut RLS jeder Nutzer nur SEIN EIGENES Profil ändern.
-- Dadurch schlug "User zu Admin machen" fehl (0 Zeilen geändert ->
-- "Cannot coerce the result to a single JSON object").
-- ============================================================

create policy "profiles_update_staff_role" on profiles
  for update
  using (current_role_rank() >= 2)   -- HEAD_ADMIN (2) oder OWNER (3)
  with check (current_role_rank() >= 2);
