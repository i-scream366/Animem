-- ============================================================
-- ANIMEM — Zusatz-Migration: Anzeigename getrennt vom @handle
-- Im Supabase SQL Editor einmalig ausführen (Teil 7)
--
-- username bleibt der eindeutige, unveränderliche @handle (wie bei YouTube).
-- display_name ist der frei wählbare, änderbare Anzeigename.
-- ============================================================

alter table profiles add column if not exists display_name text;
